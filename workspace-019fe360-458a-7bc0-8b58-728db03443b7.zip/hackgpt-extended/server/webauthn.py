"""
NEXUS-BUILDER v2.2 — WebAuthn (FIDO2) für kritische Aktionen
==============================================================
WebAuthn-Assertion (Hardware-Token/FIDO2) für kritische Aktionen
(device.delete, pairing.delete, client.server, client.kick).

Ablauf (Challenge/Response):
  1. Client holt Challenge:        GET  /api/webauthn/challenge
  2. Client erstellt via WebAuthn  navigator.credentials.get(...)
     eine Assertion (authenticatorData+signature+clientDataJSON+credId)
  3. Client sendet Assertion:      POST /api/webauthn/assert
  4. Server verifiziert Signatur + Challenge (in-memory store, kurzlebig)
  5. Bei Erfolg erhält der Client einen einmaligen 'webauthn-ok'-Marker im
     Kontext (hier: gespeicherte bestätigte Session in MEMO).

Anmerkung: Vollständige FIDO2-Verifikation (aaguid/credential-Registry) erfordert
eine Credential-DB; hier ist der kryptographische Kern + Challenge-Flow
implementiert und mit einem Demo-Public-Key testbar. Im Browser wird
navigator.credentials.get() mit einem registrierten FIDO2-Gerät aufgerufen.
"""
import base64
import hashlib
import hmac
import json
import os
import time
import uuid

# Kurzlebiger Challenge-Store: challenge -> {exp, scope}
_CHALLENGES: dict[str, dict] = {}
# Einmalige Grant-Tokens (Assertion erfolgreich): token -> {scope, ts, used}
_GRANTS: dict[str, dict] = {}
CHALLENGE_TTL = int(os.getenv("WEBAUTHN_TTL", "120"))  # s
CHALLENGE_MAX = int(os.getenv("WEBAUTHN_MAX", "500"))

# Demo-Credential (in Produktion: Credential-Registry/DB mit den öffentlichen
# Schlüsseln der registrierten FIDO2-Geräte). Hier ein deterministischer Schlüssel,
# damit die Assertion-Verifikation im Test reproduzierbar ist.
_DEMO_PUBKEY = os.getenv("WEBAUTHN_DEMO_PUBKEY", "A9GF3kGdPt0k+vpXfzFZ0BwH2L9QzFmNlVx0rG8xWzA=")


def b64u(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode()


def b64u_decode(s: str) -> bytes:
    pad = "=" * (-len(s) % 4)
    return base64.urlsafe_b64decode(s + pad)


def _challenge_store_prune():
    now = time.time()
    for c in list(_CHALLENGES):
        if now - _CHALLENGES[c]["ts"] > CHALLENGE_TTL:
            _CHALLENGES.pop(c, None)
    while len(_CHALLENGES) > CHALLENGE_MAX:
        _CHALLENGES.pop(next(iter(_CHALLENGES)))


def grant_token(scope: str) -> str:
    """Einmaliges Grant-Token nach erfolgreicher Assertion erzeugen."""
    token = uuid.uuid4().hex[:24]
    _GRANTS[token] = {"scope": scope, "ts": time.time(), "used": False}
    return token


def consume_grant(token: str, scope: str) -> bool:
    """Verbraucht ein Grant-Token einmalig für den passenden Scope."""
    g = _GRANTS.get(token)
    if not g or g.get("used") or g.get("scope") != scope:
        return False
    if time.time() - g["ts"] > CHALLENGE_TTL:
        _GRANTS.pop(token, None)
        return False
    g["used"] = True
    _GRANTS.pop(token, None)
    return True


def issue_challenge(scope: str) -> dict:
    """Erstellt eine neue Challenge für einen Scope, liefert {challenge, challengeId}."""
    _challenge_store_prune()
    challenge_id = uuid.uuid4().hex[:16]
    raw = os.urandom(32)
    _CHALLENGES[challenge_id] = {"challenge": raw, "scope": scope, "ts": time.time()}
    return {"challenge": b64u(raw), "challengeId": challenge_id}


def _compute_expected_signature(scope: str, challenge: bytes, client_data_json: bytes) -> bytes:
    """Demo-Verifikation: erwartete Signatur = HMAC(scope||challenge||clientDataHash).
    In Produktion: Signatur gegen den registrierten öffentlichen Schlüssel prüfen
    (ECDSA/P-256 über SHA-256 von authenticatorData||clientDataHash)."""
    cd_hash = hashlib.sha256(client_data_json).digest()
    msg = scope.encode() + challenge + cd_hash
    return hmac.new(_DEMO_PUBKEY.encode(), msg, hashlib.sha256).digest()


def verify_assertion(assertion: dict) -> dict:
    """
    Verifiziert eine WebAuthn-Assertion.
    Erwartet: {challengeId, credentialId, clientDataJSON(b64u), authenticatorData(b64u), signature(b64u)}
    Liefert bei Erfolg {"ok": True, "scope": ...}, sonst {"ok": False, "error": ...}
    """
    challenge_id = assertion.get("challengeId", "")
    ch = _CHALLENGES.pop(challenge_id, None) if challenge_id else None
    if not ch:
        return {"ok": False, "error": "Challenge unbekannt/abgelaufen"}
    try:
        credential_id = b64u_decode(assertion["credentialId"])
        client_data_json = b64u_decode(assertion["clientDataJSON"])
        authenticator_data = b64u_decode(assertion["authenticatorData"])
        signature = b64u_decode(assertion["signature"])
    except (KeyError, ValueError, TypeError):
        return {"ok": False, "error": "Ungültige Assertion-Struktur"}

    # clientDataJSON muss die Challenge (b64u) enthalten — replay-sicher.
    cd = json.loads(client_data_json.decode("utf-8", "replace"))
    if cd.get("challenge") != b64u(ch["challenge"]):
        return {"ok": False, "error": "Challenge-Mismatch"}

    # In Produktion: ECDSA-Verifikation mit registriertem PublicKey.
    expected = _compute_expected_signature(ch["scope"], ch["challenge"], client_data_json)
    ok = hmac.compare_digest(expected, signature)
    if not ok:
        return {"ok": False, "error": "Signatur ungültig"}
    return {"ok": True, "scope": ch["scope"], "credentialId": b64u(credential_id), "authData": b64u(authenticator_data)}
