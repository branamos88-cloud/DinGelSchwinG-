"""
NEXUS-BUILDER v2.2 — Persistenz-Layer (SQLite)
===============================================
Geräte-Registry, Clients, Pairings und Audit-Trail werden in einer lokalen
SQLite-Datei persistiert (data/hackgpt.db) — Daten überleben einen Neustart.
Schema-Versionierung via PRAGMA user_version.

Begründung/Trade-off: SQLite (embedded, kein Server) ist ideal für Single-Node
Service/Field-Einsatz. Für Multi-Node/High-Availability später Postgres.
"""
import json
import os
import sqlite3
import threading

DATA_DIR = os.path.join(os.path.dirname(__file__), "..", "data")
DB_PATH = os.environ.get("HACKGPT_DB", os.path.join(DATA_DIR, "hackgpt.db"))
_lock = threading.Lock()


def _connect() -> sqlite3.Connection:
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn


def init_db() -> None:
    with _lock, _connect() as c:
        c.executescript(
            """
            CREATE TABLE IF NOT EXISTS devices(
                id TEXT PRIMARY KEY,
                data TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS clients(
                id TEXT PRIMARY KEY,
                data TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS pairings(
                id TEXT PRIMARY KEY,
                data TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS audit(
                seq INTEGER PRIMARY KEY AUTOINCREMENT,
                trace_id TEXT,
                step INTEGER,
                event TEXT,
                user TEXT,
                role TEXT,
                resource TEXT,
                action TEXT,
                result TEXT,
                detail TEXT,
                ts TEXT
            );
            CREATE INDEX IF NOT EXISTS idx_audit_trace ON audit(trace_id);
            """
        )
        c.execute("PRAGMA user_version = 1")


# --- Generische KV-Helfer ---

def kv_get(table: str) -> dict:
    with _lock, _connect() as c:
        rows = c.execute(f"SELECT id, data FROM {table}").fetchall()
        return {r["id"]: json.loads(r["data"]) for r in rows}


def kv_set(table: str, key: str, value: dict) -> None:
    with _lock, _connect() as c:
        c.execute(
            f"INSERT INTO {table}(id, data) VALUES(?,?) "
            f"ON CONFLICT(id) DO UPDATE SET data=excluded.data",
            (key, json.dumps(value, ensure_ascii=False)),
        )


def kv_del(table: str, key: str) -> None:
    with _lock, _connect() as c:
        c.execute(f"DELETE FROM {table} WHERE id=?", (key,))


# --- Spezialisiert: Audit ---

def audit_append(entry: dict) -> None:
    with _lock, _connect() as c:
        c.execute(
            "INSERT INTO audit(trace_id,step,event,user,role,resource,action,result,detail,ts) "
            "VALUES(?,?,?,?,?,?,?,?,?,?)",
            (entry["trace_id"], entry["step"], entry["event"], entry["user"], entry["role"],
             entry["resource"], entry["action"], entry["result"], entry["detail"], entry["ts"]),
        )


def audit_list(limit: int = 200, trace_id: str | None = None) -> list[dict]:
    with _lock, _connect() as c:
        if trace_id:
            rows = c.execute(
                "SELECT * FROM audit WHERE trace_id=? ORDER BY seq DESC LIMIT ?",
                (trace_id, limit),
            ).fetchall()
        else:
            rows = c.execute("SELECT * FROM audit ORDER BY seq DESC LIMIT ?", (limit,)).fetchall()
        return [dict(r) for r in rows]
