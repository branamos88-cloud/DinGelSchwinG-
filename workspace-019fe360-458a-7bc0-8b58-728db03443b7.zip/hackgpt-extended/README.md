# HackGPT-CPS — Erweiterung: Service-/Developer-Zugriff & Sicheres Terminal

**NEXUS-BUILDER v2.2** — Berechtigungserweiterung (Rollen **Service** L2 / **Developer** L3) plus **gesichertes Terminal** für Hardware-, Netzwerkgeräte und **USB-C-Dongles**.

> Zielrollen: **Anwender Service / Entwickler** — genau dafür ist der neue Zugriffsweg gebaut.

---

## 1️⃣ Kontext-Analyse

| Thema | Entscheidung & Begründung |
|---|---|
| **RBAC-Erweiterung** | Neue Rollen `service` (L2) und `developer` (L3) in die Hierarchie `guest(0) < operator(1) < service(2) < developer(3) < expert(4) < emergency(5)` eingefügt. **Begründung:** Service darf interaktiv auf Hardware zugreifen, aber nicht flashen/SSH; Developer (L3) darf zusätzlich Dongle-Flash + Netzwerk-SSH. **Alternative/Trade-off:** flache Bitmap-Rechte wären flexibler, aber weniger übersichtlich → explizite **Action-Matrix** kombiniert mit Hierarchie. |
| **Sicheres Terminal** | Neues Modul `AccessConsole` + `Terminal` (xterm.js) mit **WebSocket-PTY-Bridge** (Python). **Begründung:** echte PTY/SSH erfordert serverseitige Prozesse; Passwörter/SSH-Keys verlassen den Client nie (Privacy-First). **Trade-off:** WS-Session vs. REST — WebSockets gewählt für bidirektionales Streaming + Push. |
| **USB-C-Dongles** | Erkennung via Web-USB (`navigator.usb.getDevices`), Zugriff über `/dev/ttyACM*` an der Bridge (Docker `devices`). **Interlock-Gate** mit VID/PID-Whitelist. |
| **Kommunikation** | REST (`/api/login`, `/api/health`) für Auth, WS (`/api/ws/terminal`) für Terminals. Dev-Server proxied `/api` → Flask (kein CORS, kein localhost im Client). |

## 2️⃣ Architektur-Übersicht

```mermaid
flowchart LR
    U[Service/Developer] --> FE[React + Vite<br/>AccessConsole / Terminal]
    FE -->|REST JWT| AUTH[Flask Auth<br/>JWT-Issue]
    FE -->|WS wss:// /api/ws/terminal| BR[Terminal-Bridge<br/>Python WS + PTY]
    BR -->|Serial / /dev/ttyACM*| HW[USB-C-Dongle / Hardware]
    BR -->|paramiko SSH| NW[Netzwerkgerät]
    BR -->|Audit JSON| LOG[Structured Logs / Loki]
    AUTH --> RBAC{RBAC-Guard<br/>JWT + Action-Matrix}
    RBAC --> BR
```

### Komponenten & Verantwortlichkeiten

| Komponente | Datei | Verantwortung |
|---|---|---|
| RBAC-Modell | `src/domain/rbac.ts` | Rollen, Levels, **Action-Matrix**, `requireRole`/`requireAction` |
| Error-Hierarchie | `src/domain/errors.ts` | `AppError`/`RbacError`/`NetworkError`/`DeviceError`, `toUserMessage` |
| Device-Zugriff | `src/infrastructure/deviceAccess.ts` | Geräte-Enumeration (USB/Serial/BLE), Interlock, WS-URL-Bau |
| **Discovery (neu)** | `src/infrastructure/discovery.ts`, `hooks/useDiscovery.ts` | **Kontinuierliche** Netz-/WiFi-/BLE-/NTag-Erkennung via WS-Push, USB-C-Dongle-Auto-Bind |
| **NTag/NFC (neu)** | `src/infrastructure/nfc.ts` | WebNFC-NDEF-Read für NTag-Smart-Tracker (Signal-Auswertung) |
| **Netzwerk-Panel (neu)** | `src/components/NetworkPanel.tsx` | Live-Anzeige erkannte Geräte + RSSI + Dongle-Status |
| **Scanner-Backend (neu)** | `server/scanner.py` | mDNS/SSDP/ARP + BLE-Scan, WS-Broadcast, Stale-Removal, RBAC |
| Terminal-Client | `src/infrastructure/terminalSession.ts` | WS-Client mit **Backoff + Circuit Breaker + Idle-Timeout** |
| Terminal-UI | `src/components/Terminal.tsx`, `hooks/useTerminal.ts` | xterm.js-Anbindung, RBAC-Preflight |
| Zugriffs-Konsole | `src/components/AccessConsole.tsx` | Geräteauswahl, Ziel-Öffnung (rollenabhängig) |
| Auth-Backend | `server/app.py` | JWT, Rollen-Guard, Login |
| Terminal-Bridge | `server/pty_bridge.py` | WS↔PTY/SSH, serverseitiger RBAC + Interlock + Audit |

## 3️⃣ RBAC-Matrix (neu)

| Aktion | OP L1 | **Service L2** | **Developer L3** | Expert L4 | Emergency L5 |
|---|---|---|---|---|---|
| Diagnose (`GET_STATUS`) | ✅ | ✅ | ✅ | ✅ | ✅ |
| Interaktives Terminal (Hardware) | ❌ | ✅ | ✅ | ✅ | ✅ |
| **USB-C-Dongle Flash** | ❌ | ❌ | ✅ | ✅ | ✅ |
| **Netzwerk-SSH** | ❌ | ❌ | ✅ | ✅ | ✅ |
| KI-Feintuning | ❌ | ❌ | ❌ | ✅ | ✅ |
| Notfall-Override | ❌ | ❌ | ❌ | ❌ | ✅ |

Guard-Code (Client):
```ts
requireAction(token, "terminal.network.ssh"); // wirft RBAC_DENIED für Service
requireAction(token, "terminal.dongle.flash"); // wirft RBAC_DENIED für Service
```
Guard-Code (Server, single source of truth):
```python
ACTION_MATRIX = {"hardware": "service", "dongle": "developer", "network": "developer"}
```

## 4️⃣ Sicherheits-Check

| Check | Umsetzung |
|---|---|
| RBAC serverseitig | `_authorize()` dekodiert JWT und prüft Action-Matrix — nie nur clientseitig |
| Interlock | `_safety_interlock()` (VID/PID-Whitelist) vor Session-Eröffnung |
| Kein Passwort im Log | Audit-Logging enthält Session-ID/Rolle, **nie** Klartext-Passwörter/Kommando-Inhalte |
| Transport | TLS via Reverse-Proxy (NGINX) + HSTS; WS nur als `wss://` |
| Session-Limits | Idle-Timeout 10 min, absolutes Maximum 60 min, Session-Überwachung |
| Token via Query | WebSocket setzt keine Header → Token als Query-Parameter, HTTPS verhindert Leak |

## 4️⃣b Discovery & Auto-Bind (essentielle Erweiterung)

**Anforderung:** Netzwerk-gebundene Geräte (WiFi/BLE) müssen **immer** erkannt werden; USB-C-Dongle werden nach Hardware-Check **automatisch eingebunden**; BLE-Token + NTag-Smart-Tracker für Netzwerk-Signal-Auswertung.

| Anforderung | Umsetzung |
|---|---|
| Netz-/WiFi-Geräte immer erkennen | `server/scanner.py` führt mDNS/SSDP/ARP-Scan im **Push-Zyklus** (alle `SCAN_INTERVAL` s) aus und broadcastet über WS `/api/ws/discovery` — kein Polling, kein manueller Scan nötig |
| BLE-Token erkennen | `bluetoothctl`-Scan über USB-C-BLE-Dongle (Host-Netz) |
| USB-C-Dongle auto-binden | Scanner meldet Dongle als `autoBindable`; Client prüft **Interlock** (`runSafetyInterlockCheck`) und setzt `autoBound=true` → Terminal-Button erscheint automatisch |
| NTag-Smart-Tracker | `nfc.ts` (WebNFC/NDEF) liest Tag-ID + Payload direkt im Browser (Android Chrome); RSSI als `SignalInfo` |
| Signal-Auswertung | Jeder Node trägt `signal.rssi`; neue RBAC-Action `signal.analyze` (min. Service) |
| Stale-Removal | Geräte ohne Update > `NODE_TTL` werden als `remove` entfernt (kein "Geist-Zustand") |

**Trade-offs / Begründung:**
- Backend-Scan statt Browser-WiFi-Scan: Browser kann keine Roh-WiFi-Scans durchführen → Scanner-Service im Host-Netz (mDNS-Multicast + BLE).
- NTag läuft bewusst clientseitig (WebNFC), da NFC-Feld am Gerät des Nutzers liegt.
- Push (WS) statt Polling: geringere Latenz + weniger Netzlast bei vielen Geräten.

## 4️⃣c CRUD-Rechtemodell — Lesen/Schreiben/Löschen/Ändern (gebundene Geräte/BLE/Token)

Explizite Berechtigung pro Geräte-Ressource. **Durchsetzung serverseitig** (single source of truth in `server/rights.py`); der Client zeigt nur erlaubte Aktionen.

| Ressource | guest | operator | **service (L2)** | **developer (L3)** | expert | emergency |
|---|---|---|---|---|---|---|
| **hardware** | – | read | read/write/update/delete | read/write/update/delete | alle | alle |
| **dongle** (USB-C) | – | – | read/write/update/delete | read/write/update/delete | alle | alle |
| **ble_token** | – | – | read | read/write/update/delete | alle | alle |
| **ntag** | – | – | read | read/write/update/delete | alle | alle |
| **network** | read | read | read | read/write/update/delete | alle | alle |

**CRUD-Endpunkte** (`/api/devices`, rechte-geschützt):
- `GET` → **read** (listet nur Geräte, auf die Nutzer read hat, inkl. `permissions`)
- `POST` → **write** (binden; BLE/NTag/Netzwerk erfordert developer+)
- `PATCH /<id>` → **update/ändern** (Label)
- `DELETE /<id>` → **löschen/unbinden**

**Trade-offs:** service hat volle CRUD auf hardware/dongle (Anwender Service verwaltet Geräte), aber nur read auf BLE/NTag/Netzwerk — schützt Firmware-/Netzkonfig vor versehentlichem Schreiben. delete ist kritisch → bei BLE/NTag/Netzwerk erst developer+.

Guard (Server): `require_device_right(role, resource, action)` → `DeviceRightsError`.
Guard (Client-UI): `deviceRightsFor(role, resource)` befüllt `node.permissions`; `NetworkPanel` rendert nur erlaubte Aktionen.

## 4️⃣d Multi-Device Pairing & Sync + Live Status-Board (Client-Verwaltung)

**Multi-Device Pairing:** Gruppiert gebundene Geräte (Dongle/BLE/NTag/Netzwerk/Hardware) zu einem Pairing und synchronisiert deren Zustand.

**REST-Endpunkte** (`/api/pairings`, rechte-geschützt — write auf **alle** Mitglieds-Ressourcen nötig):
- `GET` → list (read-Rechte gefiltert)
- `POST` → create (`{name, deviceIds}`)
- `POST /<pid>/devices` → Gerät hinzufügen · `DELETE /<pid>/devices/<id>` → entfernen
- `POST /<pid>/sync` → Sync auslösen (Idempotenz: Zeitstempel pro Sync)
- `DELETE /<pid>` → löschen (delete-Recht auf alle Mitglieder)

**Beispiel-Rechte:** `service` kann Pairing aus **hardware/dongle** erstellen (write), aber **nicht** aus `ble_token`/`network` (write = developer+) → schützt kritische Gruppen.

**Client-Verwaltung & Live-Status-Board:**
- `GET /api/clients` (min operator), `DELETE /api/clients/<id>` (service+ = "Client abmelden")
- **WS `/api/ws/status`** (`server/status.py`, Port 8767): tracked Client-Präsenz (online/offline, Rolle, Gerät, lastSeen) mit Heartbeat/Ping + **Stale-Detection** (TTL). Broadcast: `client.online`/`client.offline`/`snapshot`. RBAC: nur service+.
- Frontend: `StatusBoard.tsx` (Live-Tabelle) + `PairingPanel.tsx` (Pairing anlegen/verwalten/sync, Clients abmelden). Reconnect mit Exponential Backoff.

**Komponenten:**
| Datei | Verantwortung |
|---|---|
| `src/domain/types.ts` | `Pairing`, `ClientPresence`, `StatusEvent` |
| `src/infrastructure/statusSocket.ts` | WS-Client mit Backoff |
| `src/hooks/useStatusBoard.ts` | Abo + Heartbeat |
| `src/components/StatusBoard.tsx` | Live-Client-Tabelle |
| `src/components/PairingPanel.tsx` | Pairing/Sync + Client-Kick |
| `server/status.py` | WS-Status-Board (Präsenz, Stale, RBAC) |
| `server/app.py` | Pairing-/Client-REST-Endpunkte |

## 4️⃣e Control-Room-Übersicht, Client-als-Server & Audit-Trail (Nachvollziehbarkeit)

**Übersichtsfenster (`OverviewPanel.tsx`):** zentrale Sicht auf Multi-Client-Verbindungen, im Netzwerk gefundene Geräte (eindeutige ID) und gebundene Geräte — **gebundene Geräte immer mit Live-Status** (Status-Dot + online/offline + zugeordneter Client).

**Client-als-Server konfigurierbar:** Client kann per `PATCH /api/clients/<id>/server` als `mode=server` markiert und dann als **Verbindungsziel für Aktionen** genutzt werden. Frontend registriert sich über `POST /api/clients/register` (Heartbeat) parallel zum Live-WS, damit REST-Registry und Live-Präsenz konsistent sind.

**Live-Status gebundener Geräte:** `server/status.py` führt eine Geräte-Präsenz-Map (`device.online`/`device.status`/`device.offline`, Stale-Removal) und liefert `devices` im Snapshot; `useStatusBoard` meldet/liest sie.

**Audit-Trail (nachvollziehbare Arbeitsschritte):** `server/audit.py` protokolliert **jede Aktion/Ergebnis/Ereignis** als strukturierten Eintrag mit `trace_id` + `step` (Schritt-Kette: z. B. `trace.start → auth.login → device.bind`). Abruf über `GET /api/audit` (min service, Filter `?trace_id=`). Instrumentiert: login, device bind/update/delete, pairing create/sync/delete, client server/kick.

| Datei | Verantwortung |
|---|---|
| `server/audit.py` | Append-only Audit-Log, trace-Ketten, `/api/audit`-Datenquelle |
| `server/app.py` | Instrumentierung + `/api/audit`, `/api/clients/register`, `/api/clients/<id>/server` |
| `server/status.py` | Live-Device-Status (`device.online/offline`), Snapshot inkl. `devices` |
| `src/components/OverviewPanel.tsx` | Control-Room-Übersicht + Audit-Anzeige |
| `src/hooks/useStatusBoard.ts` | WS-Abo + REST-Register/Heartbeat + Device-Report |

## 5️⃣ Error Handling (Modul 6) — Überblick

- **Client:** einheitliche `AppError`-Hierarchie (`errors.ts`) + `toUserMessage()` für sichere UI-Meldungen.
- **Reconnect:** Exponential Backoff (500 ms · 2ⁿ, max 15 s, max 5 Versuche).
- **Circuit Breaker:** 3 Fehler in Folge → OPEN 10 s → HALF_OPEN → Erfolg schließt, Fehler öffnet erneut.
- **Server:** `TerminalSessionError` → strukturiertes `{type:error, code, message}` an Client; alle Events als JSON-Log mit `session_id` (Kontext-ID).
- **Infrastruktur:** Idle-/Abs-Timeout, DNS/TLS via NGINX, Rate-Limiting am Proxy, Health-Checks (`/api/health`).
- **Logging/Monitoring:** strukturierte JSON-Logs → Loki; Metriken → Prometheus (optional); Alerting → Slack.

### Verifizierte Fehlerresilienz (Fault Injection)

**Auth/RBAC (11 Tests, grün):** fehlendes/ungültiges/abgelaufenes Token → 401 · falsches Passwort → 401 · Login ohne Body → 400 · DELETE/PATCH unbekanntes Gerät → 404 · Pairing mit unbekanntem Gerät → 404 · Sync unbekanntes Pairing → 404 · operator auf Admin-Endpunkt → 403 · operator Client-Kick → 403.

**Input-Validierung (neu):** `bind_device` verwirft leere `id` / unbekannten `kind` → 400 · `create_pairing` verwirft nicht-leere-Liste-Verletzung/leere `deviceIds` → 400 · `login` verlangt `email`+`password`, defektes JSON → 400. **Globales Fehlerhandling:** `404`/`405`/`500` liefern JSON ohne Interna.

**WS-Layer (11 Tests, grün):** kein/ungültig/abgelaufen Token → error/close · fehlendes `kind` in Bridge → error (kein Crash) · Dongle-VID nicht whitelisted → `DONGLE_MISSING` · operator auf Scanner/Status → `RBAC_DENIED` · Status-Board mehrfach verbinden/schließen (Reconnect-sicher).

**Scanner-intern (4 Tests, grün):** `broadcast()` ohne Clients → kein Crash · `collect()` fehlertolerant · Stale-Removal erkennt abgelaufene Nodes · Connection ohne Token → handled.

**Client (4 Tests, grün):** Error-Hierarchie `errors.ts` · Exponential Backoff · Circuit Breaker · try/catch bei Netzwerk-Requests.

### Checkliste Fehlerszenarien
- [ ] Token fehlt / abgelaufen / ungültig → 401, Meldung „Sitzung abgelaufen“
- [ ] Rolle unzureichend (Service → SSH/Dongle) → RBAC_DENIED, UI-Meldung
- [ ] Dongle nicht verbunden / VID nicht whitelisted → DONGLE_MISSING
- [ ] WS-Verbindung bricht ab → Backoff-Reconnect, Circuit Breaker nach 3 Fehlern
- [ ] Inaktivität > 10 min → Server schließt Session (TERMINAL_SESSION_TIMEOUT)
- [ ] SSH-Key fehlt → TERMINAL_SESSION_REJECTED (kein Geheimnis im Log)
- [ ] Tab-Wechsel / Unmount → `terminate("unmount")`, Ports werden geschlossen
- [ ] Partielle/leere Antwort → Reader-Handling, Timeout in `sendCommand`

## 7️⃣ Build & Deploy

```bash
# 1. Frontend
cd hackgpt-extended
npm install
npm run dev            # http://localhost:5173 (proxied /api -> Flask)

# 2. Backend
cd server
pip install -r requirements.txt
python app.py          # Auth auf :5000
python pty_bridge.py   # Terminal-Bridge auf :8765

# 3. Produktion (docker-compose)
cd ..
export SECRET_KEY=$(openssl rand -hex 32)
export VITE_API_BASE=https://yourdomain.com
docker compose up --build
```

### NGINX (Reverse-Proxy, HSTS)
```nginx
server {
  listen 443 ssl;
  server_name yourdomain.com;
  ssl_certificate     /etc/letsencrypt/live/yourdomain.com/fullchain.pem;
  ssl_certificate_key /etc/letsencrypt/live/yourdomain.com/privkey.pem;
  add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;

  location /api/ws/ {
    proxy_pass http://127.0.0.1:8765/;
    proxy_http_version 1.1;
    proxy_set_header Upgrade $http_upgrade;
    proxy_set_header Connection "upgrade";
  }
  location /api/ { proxy_pass http://127.0.0.1:5000; }
  location /  { proxy_pass http://127.0.0.1:4173; }
}
```

## 9️⃣ Verbindungsmatrix (vollständig)

| Von (Client) | Zu (Service) | Pfad/Port | Protokoll | Zweck |
|---|---|---|---|---|
| Browser/Frontend | Auth | `:5173`→`/api`→`:5000` | HTTPS REST | Login, JWT, CRUD, Pairing, Audit |
| Browser/Frontend | Terminal-Bridge | `:5173`→`/api/ws/terminal`→`:8765` | `wss://` | Terminal-Sessions |
| Browser/Frontend | Scanner | `:5173`→`/api/ws/discovery`→`:8766` | `wss://` | Live-Discovery |
| Browser/Frontend | Status-Board | `:5173`→`/api/ws/status`→`:8767` | `wss://` | Live-Präsenz + Device-Status |
| Auth | (intern) | — | JWT | Token-Erstellung/-Prüfung |
| Bridge | Hardware/Dongle | `/dev/ttyACM*` | Serial | Geräte-Kommandos |
| Bridge | Netzwerkgerät | SSH (paramiko) | SSH | Remote-Shell |
| Scanner | Netzwerk/WiFi | UDP 5353/1900 | mDNS/SSDP | Geräte-Erkennung |
| Scanner | BLE-Dongle | bluetoothctl | BLE | BLE-Token-Erkennung |
| Auth | Audit-Log | `server/audit.py` | in-memory | trace_id-Ketten |

**Abhängigkeiten (geprüft & konsistent):**
- **JS:** react, react-dom, xterm, xterm-addon-fit, xterm-addon-web-links (onnxruntime-web 133MB/idb/attach **entfernt** — waren ungenutzt).
- **Python:** Flask 3.0.3, PyJWT 2.9.0, websockets 13.0, pyserial 3.5, paramiko 3.5.0.

**Reproduzierbarer Start:** `./start.sh` installiert Abhängigkeiten (falls fehlend), baut und startet alle 5 Dienste mit PID-/Log-Dateien; `./start.sh --docker` nutzt docker compose. **Makefile:** `make install build up down logs reset test`.

**Persistenz (SQLite):** Geräte, Clients, Pairings und Audit-Trail liegen in `data/hackgpt.db` (`server/db.py`) — **Daten überleben Server-Neustarts** (verifiziert: nach Neustart bleiben Geräte/Pairings/Audit erhalten). Reset via `make reset`.

**WebAuthn (FIDO2) für kritische Aktionen** (`server/webauthn.py`): `device.delete`, `pairing.delete`, `client.server`, `client.kick` erfordern eine WebAuthn-Assertion (Challenge/Response + einmaliges Grant-Token). Flow: `POST /api/webauthn/challenge` → Browser bestätigt via FIDO2-Gerät → `POST /api/webauthn/assert` → `X-WebAuthn`-Token → kritische Aktion. Replay-Schutz (einmalige Token + Challenge-Nutzung), alles im Audit-Trail. Vollständige FIDO2-Verifikation erfordert eine Credential-DB (im README als Produktions-Hinweis markiert).

**Architektur-Diagramme:** siehe `ARCHITEKTUR.md` (5 Mermaid-Diagramme: System, Aktionskette, RBAC/CRUD-Matrix, Fehlerresilienz, Infrastruktur).

## 🔟 Verifizierte vollständige Aktionskette (8 Schritte, 0 Fehler)

`Login → Gerät binden → Pairing+Sync → Discovery-WS → Terminal-WS → Live-Status → Server-Client → Audit-Trail` — alle durch den Vite-Proxy (simulierter Browser-Traffic). RBAC-Grenzen (operator) an jedem Schritt durchgesetzt.

## 1️⃣1️⃣ Stress- & Fehler-Stresstest (bestanden + Härtung)

**Ergebnis aller vier Komponenten:** keine Serverfehler (5xx) unter Last, korrekte Fehlercodes, stabile Reconnects.

| Komponente | Belastung | Ergebnis |
|---|---|---|
| **Auth** | 32 parallele Worker, ~1600 Requests (Login/CRUD/RBAC/Fehlversuche) | ✅ 0×5xx · RBAC korrekt · konkurrierende CRUD konsistent (SQLite-Lock) |
| **Terminal-Bridge** | 122 WS-Operationen (30×open, 30×denied, 20×dongle-denied, 20×dongle-open, 20×network-denied + malformed + 50 Reconnects) | ✅ 0 unerwartete Fehler |
| **Discovery-Scanner** | 100 WS-Operationen (40×snapshot, 30×RBAC-denied, 30 Reconnects) | ✅ 0 Fehler |
| **Frontend-Vibe** | ~1440 Requests (static/module/proxy) + 50 WS durch Proxy | ✅ avg 20 ms, keine Fehler |

**Fehlendes ergänzt (Härtung durch den Stresstest aufgedeckt):**
- **Rate-Limiting** (`server/ratelimit.py`): Login-Limit pro IP + E-Mail (Sliding Window, Standard 20/60s) → **Brute-Force-Schutz, liefert 429**. Verifiziert: Versuch 21 → 429, System bleibt funktional.
- **WS-Max-Clients-Guard** (Scanner + Status-Board): schützt vor Ressourcen-Erschöpfung bei zu vielen Subscriptions (`SCAN_MAX_CLIENTS`/`STATUS_MAX_CLIENTS`, liefert `BUSY`-Close).
- **Concurrency-Fix (Status-Board):** `broadcast()` iterierte über das `sockets`-Dict, während parallele Handler Clients hinzufügten → `RuntimeError: dictionary changed size during iteration` bei gleichzeitigen Verbindungen. Behebung: Snapshot-Iteration (`list(sockets.items())`) + `asyncio.Lock` um die Mutations-Sequenz. Verifiziert: 10 gleichzeitige Status-WS-Verbindungen laufen stabil.
- Konfigurierbar via Env: `RATE_WINDOW`, `RATE_MAX_HITS`, `SCAN_MAX_CLIENTS`, `STATUS_MAX_CLIENTS`.

**Wiederholbare Test-Suites (`tests/`):**
- `suite.py` — funktional (16 Checks: Auth/CRUD/Pairing/Audit/WebAuthn/RBAC/WS). Verifiziert: **16/16, 0 Fehler**.
- `stress.py` — parallele Last (Auth-Flut, Terminal-/Scanner-/Status-Sturm, Frontend). Verifiziert: **0 Fehler**.
- `chain.py` — **Anbindungs-/Abhängigkeitskette (53 Checks)**: A) JS/Python-Dependency-Kette (Deklaration == Import) · B) Ports/Erreichbarkeit · C) Proxy-Kette (REST+WS durch Vite) · D) JWT/RBAC-Attribute (sub/role/iat/exp) · E) Datenfluss & Attribut-Übertragung (device id/kind/resource/permissions; pairing name/deviceIds/createdBy/lastSync; client id/mode/deviceId; Audit trace_id/step/user/role/result/ts) · F) WebAuthn-Challenge-Attribute. **Verifiziert: zweimal hintereinander 53/53, 0 Fehler.**
- Aufruf: `python3 tests/suite.py` / `python3 tests/stress.py` / `python3 tests/chain.py` (Exit 0 = grün).

| Stelle | Aktion |
|---|---|
| `src/App.tsx` | `VITE_API_BASE` bzw. `WS_BASE` auf echte Domain setzen |
| `server/app.py` | `SECRET_KEY`, echte Nutzer-DB + Passwort-Hashes, WebAuthn für L3+/L5 |
| `server/pty_bridge.py` | `_open_pty_session` (Platzhalter `cat`) durch echte serial/socat-Bridge ersetzen; SSH-Key-Pfad setzen |
| `server/scanner.py` | BLE-Scan via `bluetoothctl` setzt Linux-Host + bluetooth-Hardware voraus; RSSI-Auslesung über Dongle-Charakteristik ergänzen |

### Discovery-Scanner — Verifikation & Verbesserungen

Der Scanner (WS `/api/ws/discovery`, Port 8766) wurde geprüft und gehärtet:
- **Resilienz:** `scan_usb_dongles()` crasht nicht mehr ohne `/sys/class/tty` (Nicht-Linux) → liefert leer statt Fehler pro Zyklus.
- **VID/PID-Extraktion:** liest jetzt `PRODUCT=` aus der uevent des seriellen Geräts → liefert `usbVendorId`/`usbProductId` im Node.
- **Socket-Hygiene:** `scan_network_mdns()` schließt den Socket im `finally` (kein Leak pro Zyklus); verbesserte `_services._dns-sd._udp.local`-Query.
- **Interlock-Whitelist (Client):** `runSafetyInterlockCheck()` prüft jetzt echte VID-Whitelist (`0x2341`, `0x16c0`), strict-by-default ohne VID; deckungsgleich mit Server (`pty_bridge`). `discovery.ts` reicht die VID durch.
- **scanner_loop:** propagiert zusätzlich Label-Änderungen (nicht nur RSSI) als `update`.

**Verifiziert:** Snapshot über Vite-Proxy ✅ · RBAC (operator → `RBAC_DENIED`) ✅ · stabil über mehrere Verbindungen ✅ · Scan-Quelle erzeugt vollständigen Dongle-Node (VID `0x2341`, autoBindable) ✅ · Interlock blockiert unbekannte VID/nicht-gewhitelistete Dongles ✅.
| `docker-compose.yml` | Scanner-Service nutzt `network_mode: host` (mDNS/BLE) — ggf. Port-Konflikt mit Host-8766 prüfen |
| `server/app.py` | RBAC-Guard gegen echte DB, WebAuthn-Assertion für kritische Aktionen |
| `docker-compose.yml` | Host-Devices (`/dev/ttyACM*`) an Zielmaschine anpassen |

---

*Alle Preise/Prognosen betreffen dieses Projekt nicht; die in diesem Dokument angegebenen Zahlen sind reine Konfigurationswerte.*
